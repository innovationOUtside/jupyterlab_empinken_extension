"use strict";
(self["webpackChunkjupyterlab_empinken_extension"] = self["webpackChunkjupyterlab_empinken_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);

//import {CellList} from '@jupyterlab/notebook'; //gets list from ISharedNotebook
//import { Cell } from '@jupyterlab/cells';

// Remove items in first list from second list
function removeListMembers(list1, list2) {
    return list2.filter(item => !list1.includes(item));
}
/**
 * The plugin registration information.
 */
// https://jupyterlab.readthedocs.io/en/stable/api/index.html
// https://jupyterlab.readthedocs.io/en/3.3.x/api/interfaces/notebook.inotebooktracker.html
const empinken_tags_ = ["activity", "learner", "solution", "tutor"];
let empinken_tags = empinken_tags_;
const plugin = {
    id: 'jupyterlab_empinken_extension:plugin',
    description: 'A JupyterLab extension adding a button to the Notebook toolbar.',
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker, _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    autoStart: true,
    activate: (app, notebookTracker, settings) => {
        const { commands } = app;
        console.log("Activating empinken");
        let tag_prefix = '';
        /**
         * Load the settings for this extension
         *
         * @param setting Extension settings
         */
        Promise.all([settings.load(plugin.id)])
            .then(([setting]) => {
            // Read the settings
            //loadSetting(setting);
            const root = document.documentElement;
            const updateSettings = () => {
                if (setting.get('use_tagprefix').composite) {
                    tag_prefix = setting.get('tagprefix') ? setting.get('tagprefix').composite.toString() : '';
                }
                else
                    tag_prefix = '';
                empinken_tags = [];
                for (const tag of empinken_tags_) {
                    const prefixed_tag = tag_prefix + tag;
                    empinken_tags.push(prefixed_tag);
                }
                // Update the document CSS colour settings
                for (let typ of empinken_tags_) {
                    const color = setting.get(typ + '_color').composite;
                    // if a tag rendering is disabled, set the colour as the theme
                    if (setting.get(typ + '_render').composite)
                        root.style.setProperty('--iou-' + typ + '-bg-color', color);
                    else
                        root.style.setProperty('--iou-' + typ + '-bg-color', "var(--jp-cell-editor-background)");
                }
            };
            updateSettings();
            // Listen for your plugin setting changes using Signal
            setting.changed.connect(updateSettings);
            const createEmpinkenCommand = (label, type) => {
                //this works wrt metadata
                const caption = `Execute empinken ${type} Command`;
                return {
                    label,
                    caption,
                    execute: () => {
                        var _a;
                        let activeCell = notebookTracker.activeCell;
                        //console.log(label, type, caption)
                        //console.log(activeCell)
                        const nodeclass = 'iou-' + type + "-node";
                        if (activeCell !== null) {
                            let tagList = (_a = activeCell.model.getMetadata("tags")) !== null && _a !== void 0 ? _a : [];
                            //console.log("cell metadata was", tagList, "; checking for", type);
                            let tagtype = tag_prefix + type;
                            if (tagList.includes(tagtype)) {
                                // ...then remove it
                                const index = tagList.indexOf(tagtype, 0);
                                if (index > -1) {
                                    tagList.splice(index, 1);
                                }
                                activeCell.model.setMetadata("tags", tagList);
                                // Remove class
                                activeCell.node.classList.remove(nodeclass);
                                // cell.node.classList exists
                            }
                            else {
                                // remove other tags
                                tagList = removeListMembers(empinken_tags, tagList);
                                empinken_tags_.forEach((tag) => {
                                    activeCell.node.classList.remove('iou-' + tag + "-node");
                                });
                                // add required tag
                                tagList.push(tagtype);
                                activeCell.model.setMetadata("tags", tagList);
                                // if we want to render that tag:
                                if (setting.get(type + "_render").composite)
                                    activeCell.node.classList.add(nodeclass);
                            }
                            //console.log("cell metadata now is", tagList);
                        }
                    }
                };
            };
            // This attaches a command to a button
            // If we want to hide the buttons, we need to manually register
            // them as widgets — or not — rather than add them via the plugin.json file
            empinken_tags_.forEach((tag) => {
                if (setting.get(tag + '_button').composite)
                    commands.addCommand('ouseful-empinken:' + tag, createEmpinkenCommand(tag.charAt(0).toUpperCase(), tag));
            });
        });
        //labshell via https://discourse.jupyter.org/t/jupyterlab-4-iterating-over-all-cells-in-a-notebook/20033/2
        const labShell = app.shell;
        labShell.currentChanged.connect(() => {
            const notebook = app.shell.currentWidget;
            if (notebook) {
                notebook.revealed.then(() => {
                    var _a;
                    (_a = notebook.content.widgets) === null || _a === void 0 ? void 0 : _a.forEach(cell => {
                        var _a;
                        const tagList = (_a = cell.model.getMetadata('tags')) !== null && _a !== void 0 ? _a : [];
                        console.log("cell metadata", tagList);
                        tagList.forEach((tag) => {
                            var _a;
                            if (empinken_tags.includes(tag)) {
                                //console.log("hit", tag)
                                const tag_ = tag.replace(new RegExp(tag_prefix, 'g'), '');
                                (_a = cell.node) === null || _a === void 0 ? void 0 : _a.classList.add('iou-' + tag_ + '-node');
                            }
                        });
                    });
                });
            }
        });
    }
};
/**
 * Export the plugin as default.
 */
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.7413786ebee321d09cae.js.map