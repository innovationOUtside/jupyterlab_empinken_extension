# jupyterlab-empinken-extension
Coloured JupyterLab / RetroLab notebook cells based on cell tags
