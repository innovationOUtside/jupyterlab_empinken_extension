"use strict";
(self["webpackChunkjupyterlab_empinken_extension"] = self["webpackChunkjupyterlab_empinken_extension"] || []).push([["lib_index_js-webpack_sharing_consume_default_jupyterlab_cells"],{

/***/ "./lib/empinken_commands.js":
/*!**********************************!*\
  !*** ./lib/empinken_commands.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   create_empinken_commands: () => (/* binding */ create_empinken_commands),
/* harmony export */   typs: () => (/* binding */ typs)
/* harmony export */ });
/* harmony import */ var jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jupyterlab-celltagsclasses */ "./node_modules/jupyterlab-celltagsclasses/lib/apply_on_cells.js");
/* harmony import */ var jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jupyterlab-celltagsclasses */ "./node_modules/jupyterlab-celltagsclasses/lib/metadata.js");


const typs = ['activity', 'solution', 'learner', 'tutor'];
function getFullTag(prefix, tag) {
    return `${prefix}${tag}`;
}
const toggleTag = (cell, tag, prefix) => {
    const fullTag = getFullTag(prefix, tag);
    // Metadata path to the tags
    const tags_path = 'tags';
    const hasTag = (0,jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_0__.md_has)(cell, tags_path, fullTag);
    if (hasTag) {
        // Remove the desired tag (a, s, l, t)
        (0,jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_0__.md_remove)(cell, tags_path, fullTag);
    }
    else {
        // Remove all other related tags (a, s, l, t) if present
        typs.forEach(typ => (0,jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_0__.md_remove)(cell, tags_path, getFullTag(prefix, typ)));
        // Set the tag
        (0,jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_0__.md_insert)(cell, tags_path, fullTag);
    }
    console.log(`Toggled cell tag ${fullTag}`, cell.node);
};
const create_empinken_commands = (app, notebookTracker, palette, settings) => {
    const prefix = settings && typeof settings.get('tagprefix').composite === 'string'
        ? settings.get('tagprefix').composite
        : '';
    const add_command = (suffix, tag, label, scope, keys, settings, the_function) => {
        let display_button = true;
        if (settings != null) {
            display_button = settings.get(`${tag}_button`).composite;
        }
        if (display_button) {
            const command = `ouseful_empinken:${suffix}`;
            app.commands.addCommand(command, {
                label,
                execute: () => {
                    console.log(label);
                    (0,jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_1__.apply_on_cells)(notebookTracker, scope, the_function);
                }
            });
            palette.addItem({ command, category: 'celltagsclasses' });
            app.commands.addKeyBinding({
                command,
                keys,
                selector: '.jp-Notebook'
            });
        }
    };
    typs.forEach(typ => {
        // Use a simple label text label for the button
        // Really this should be a vector image?
        const label = typ[0].toUpperCase();
        add_command(`empkn_${typ}`, typ, label, jupyterlab_celltagsclasses__WEBPACK_IMPORTED_MODULE_1__.Scope.Active, [], settings, (cell) => toggleTag(cell, typ, prefix));
    });
};


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _empinken_commands__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./empinken_commands */ "./lib/empinken_commands.js");




/**
 * Initialization data for the jupyterlab_empinken_extension extension.
 */
const plugin = {
    id: 'jupyterlab_empinken_extension:plugin',
    description: 'A JupyterLab extension for colouring notebook cell backgrounds.',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ICommandPalette],
    optional: [_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_0__.ISettingRegistry],
    activate: (app, notebookTracker, palette, settingRegistry) => {
        console.log('JupyterLab extension jupyterlab_empinken_extension is activated!');
        let settings = null;
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(loaded_settings => {
                settings = loaded_settings;
                console.log('jupyterlab_empinken_extension settings loaded:', settings.composite);
                // Handle the background colours
                // The document object seems to be magically available?
                const root = document.documentElement;
                const updateSettings = () => {
                    if (settings != null) {
                        // The CSS tag type are used in the pre-defined CSS variables (see: base.css)
                        for (let typ of _empinken_commands__WEBPACK_IMPORTED_MODULE_3__.typs) {
                            let color = settings.get(`${typ}_color`).composite;
                            const render = settings.get(`${typ}_render`)
                                .composite;
                            if (!render)
                                color = 'transparent';
                            root.style.setProperty(`--iou-${typ}-bg-color`, color);
                        }
                    }
                };
                updateSettings();
                // We can auto update the color
                settings.changed.connect(updateSettings);
                (0,_empinken_commands__WEBPACK_IMPORTED_MODULE_3__.create_empinken_commands)(app, notebookTracker, palette, settings);
            })
                .catch(reason => {
                console.error('Failed to load settings for jupyterlab_empinken_extension.', reason);
            });
        }
        else {
            // If settingRegistry is null, call create_empinken_commands with null settings
            (0,_empinken_commands__WEBPACK_IMPORTED_MODULE_3__.create_empinken_commands)(app, notebookTracker, palette, null);
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js-webpack_sharing_consume_default_jupyterlab_cells.eca91cdbc5bfb5ab1d13.js.map